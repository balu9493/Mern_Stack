# Course contents

Simple web app for getting used to collections & modules

## Start the application

To start an application, do the following :

```bash
# Install dependancies
$ yarn install
# Start the application
$ yarn start
```

You can then access the app on : [http://localhost:3000/](http://localhost:3000/)