# Solutions for part 8 exercises

This part of the course is about GraphQL, Facebook's alternative to REST for communication between browser and a server.
